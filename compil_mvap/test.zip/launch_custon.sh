#!/bin/bash

./custom_run_tests.sh Calculette.g4 VariableInfo.java TableSimple.java TablesSymboles.java
